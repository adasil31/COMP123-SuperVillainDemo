﻿namespace SuperVillainDemo
{
    public class Villain
    {
        private string malice;

        public Villain(string malice)
        {
            this.malice = malice;
        }
    }
}